from typing import Any, List, Dict, Optional
import re

def get_current_order() -> Dict[str, Any]:
    """
    Retrieves the current list of items in the customer's order, along with their quantities and prices.

    Args:
        None

    Returns:
        Dict[str, Any]: A dictionary containing the order items and the calculated subtotal.
                        Example: {"status": "SUCCESS", "order_items": [{"name": "Aloo Chaat", "quantity": 2, "price": 210}], "subtotal": 420}
                        Example: {"status": "SUCCESS", "order_items": [], "subtotal": 0, "message": "Your order is empty."}
    """
    # MOCK: This function retrieves the current order from the context state.

    current_order = context.state.get("current_order", [])
    
    if not current_order:
        return {"status": "SUCCESS", "order_items": [], "subtotal": 0, "message": "Your order is empty."}

    subtotal = sum(item["price"] * item["quantity"] for item in current_order)
    
    # Return a copy of the order items to prevent external modification
    return {"status": "SUCCESS", "order_items": [item.copy() for item in current_order], "subtotal": subtotal}