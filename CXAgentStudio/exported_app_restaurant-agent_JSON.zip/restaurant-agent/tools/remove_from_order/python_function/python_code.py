from typing import Any, List, Dict, Optional
import re

def remove_from_order(item_name: str, quantity: Optional[int] = 1) -> Dict[str, Any]:
    """
    Removes a specified quantity of a menu item from the current order.
    If quantity is not specified, one unit of the item is removed.
    If the quantity to remove exceeds the quantity in the order, the item is fully removed.

    Args:
        item_name (str): The name of the menu item to remove.
        quantity (Optional[int]): The number of units of the item to remove. Defaults to 1.

    Returns:
        Dict[str, Any]: A dictionary indicating success or failure, with a message and the updated
                        count of items in the current order.
                        Example: {"status": "SUCCESS", "message": "Removed 1 Aloo Chaat from your order.", "current_order_count": 1}
                        Example: {"status": "FAILED", "message": "Item 'Pizza' not found in your order."}
    """
    # MOCK: This function simulates removing an item from a customer's order.
    # It uses the context.state to store the current order.

    if quantity <= 0:
        return {"status": "FAILED", "message": "Quantity to remove must be a positive integer."}

    current_order = context.state.get("current_order", [])
    
    item_found = False
    for i, order_item in enumerate(current_order):
        if order_item["name"].lower() == item_name.lower():
            item_found = True
            if order_item["quantity"] <= quantity:
                # Remove the entire item if quantity to remove is greater or equal
                del current_order[i]
                message = f"Removed all {order_item['name']} from your order."
            else:
                order_item["quantity"] -= quantity
                message = f"Removed {quantity} {order_item['name']} from your order."
            break
    
    if not item_found:
        return {"status": "FAILED", "message": f"Item '{item_name}' not found in your current order."}

    context.state["current_order"] = current_order
    total_items_in_order = sum(item["quantity"] for item in current_order)
    return {"status": "SUCCESS", "message": message, "current_order_count": total_items_in_order}