from typing import Any, List, Dict, Optional
import re

def generate_invoice() -> Dict[str, Any]:
    """
    Generates a final invoice for the current order, including subtotal, GST (5%), and total amount.
    After generating the invoice, the current order is cleared.

    Args:
        None

    Returns:
        Dict[str, Any]: A dictionary containing the invoice details or a failure message if the order is empty.
                        Example: {"status": "SUCCESS", "subtotal": 835, "gst_amount": 41.75, "total_amount": 876.75, "message": "Invoice generated successfully."}
                        Example: {"status": "FAILED", "message": "Cannot generate invoice for an empty order."}
    """
    # MOCK: This function calculates the final bill and clears the order.

    current_order = context.state.get("current_order", [])

    if not current_order:
        return {"status": "FAILED", "message": "Cannot generate invoice for an empty order."}

    subtotal = sum(item["price"] * item["quantity"] for item in current_order)
    gst_rate = 0.05  # 5% GST
    gst_amount = round(subtotal * gst_rate, 2)
    total_amount = round(subtotal + gst_amount, 2)

    # Clear the order after generating invoice
    context.state["current_order"] = []

    return {
        "status": "SUCCESS",
        "subtotal": subtotal,
        "gst_amount": gst_amount,
        "total_amount": total_amount,
        "message": "Invoice generated successfully."
    }