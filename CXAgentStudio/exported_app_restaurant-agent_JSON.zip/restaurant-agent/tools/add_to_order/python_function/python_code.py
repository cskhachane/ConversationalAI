from typing import Any, List, Dict, Optional
import re

def add_to_order(item_name: str, quantity: int) -> Dict[str, Any]:
    """
    Adds a specified quantity of a menu item to the current order.

    Args:
        item_name (str): The exact name of the menu item to add.
        quantity (int): The number of units of the item to add. Must be a positive integer.

    Returns:
        Dict[str, Any]: A dictionary indicating success or failure, with a message and the updated
                        count of items in the current order.
                        Example: {"status": "SUCCESS", "message": "Added 2 Aloo Chaat to your order.", "current_order_count": 2}
                        Example: {"status": "FAILED", "message": "Item 'Chicken Tikka' not found on the menu."}
    """
    # MOCK: This function simulates adding an item to a customer's order.
    # It uses the context.state to store the current order.

    if quantity <= 0:
        return {"status": "FAILED", "message": "Quantity must be a positive integer."}

    # Re-initialize MENU_DATA for item lookup, adhering to stateless tool constraint
    MENU_DATA = [
        # APPETISERS (Page 1 & 2)
        {"name": "Aloo Chaat", "price": 210, "category": "Appetisers"},
        {"name": "Samosa ki Chaat", "price": 280, "category": "Appetisers"},
        {"name": "Papdi Chaat", "price": 255, "category": "Appetisers"},
        {"name": "Paneer Tikka (Tawa)", "price": 395, "category": "Appetisers"},
        {"name": "Paneer Chilli", "price": 395, "category": "Appetisers"},
        {"name": "Paneer Kurkure", "price": 380, "category": "Appetisers"},
        {"name": "Paneer Kathi Roll", "price": 380, "category": "Appetisers"},
        {"name": "Paneer Lifafa", "price": 380, "category": "Appetisers"},
        {"name": "Sev Puri Shots", "price": 260, "category": "Appetisers"},
        {"name": "Idli Chips", "price": 190, "category": "Appetisers"},
        {"name": "Idli Chilli", "price": 260, "category": "Appetisers"},
        {"name": "Hara Bhara Kabab", "price": 260, "category": "Appetisers"},
        {"name": "Hara Bhara Kabab in Cheese Sauce", "price": 330, "category": "Appetisers"},
        {"name": "Mixed Kabab", "price": 415, "category": "Appetisers"},
        {"name": "Cheese Balls", "price": 295, "category": "Appetisers"},
        {"name": "Cheese Corn Balls", "price": 295, "category": "Appetisers"},
        {"name": "Cheese Balls in Chilli Garlic Sauce", "price": 330, "category": "Appetisers"},
        {"name": "Corn on Toast", "price": 295, "category": "Appetisers"},
        {"name": "Chilli Cheese Toast", "price": 295, "category": "Appetisers"},
        {"name": "Bruschetta", "price": 295, "category": "Appetisers"},
        {"name": "Garlic Bread (Regular)", "price": 210, "category": "Appetisers"},
        {"name": "Garlic Bread (Cheese)", "price": 260, "category": "Appetisers"},
        {"name": "Mini Pav Bhaji", "price": 260, "category": "Appetisers"},
        {"name": "Mini Vada Pav (Regular)", "price": 260, "category": "Appetisers"},
        {"name": "Mini Vada Pav (Grilled)", "price": 280, "category": "Appetisers"},
        {"name": "Sesame Seeds on Toast", "price": 215, "category": "Appetisers"},
        {"name": "Chinese Bhel", "price": 260, "category": "Appetisers"},
        {"name": "Spring Rolls", "price": 295, "category": "Appetisers"},
        {"name": "Thali Farsan (Today's Special)", "price": 260, "category": "Appetisers"},
        {"name": "Corn Bhel", "price": 250, "category": "Appetisers"},
        {"name": "Khandvi", "price": 235, "category": "Appetisers"},
        {"name": "Patra (Vagharela / Fried)", "price": 235, "category": "Appetisers"},
        {"name": "Mixed Farsan", "price": 280, "category": "Appetisers"},
        {"name": "Onion Rings", "price": 260, "category": "Appetisers"},
        {"name": "Capsicum Rings", "price": 270, "category": "Appetisers"},
        {"name": "Fried Baby Corn", "price": 295, "category": "Appetisers"},
        {"name": "Assorted Platter", "price": 340, "category": "Appetisers"},
        {"name": "Aloo Tikki", "price": 215, "category": "Appetisers"},
        {"name": "Schezwan Potato", "price": 260, "category": "Appetisers"},
        {"name": "Schezwan Idli", "price": 260, "category": "Appetisers"},
        {"name": "Schezwan Paneer", "price": 395, "category": "Appetisers"},
        {"name": "Baby Chilly Cheese Naan", "price": 250, "category": "Appetisers"},
        {"name": "Crispy Chilly Potato", "price": 260, "category": "Appetisers"},
        {"name": "French Fries", "price": 215, "category": "Appetisers"},
        {"name": "Paneer Pakoda", "price": 260, "category": "Appetisers"},
        {"name": "Cheese Pakoda", "price": 260, "category": "Appetisers"},
        {"name": "Veg Mixed Pakoda", "price": 235, "category": "Appetisers"},
        {"name": "Mini Potato Vada", "price": 190, "category": "Appetisers"},
        {"name": "Mini Punjabi Samosa", "price": 190, "category": "Appetisers"},
        {"name": "Mini Sabudana Wada", "price": 190, "category": "Appetisers"},
        {"name": "Tomato Omelette", "price": 190, "category": "Appetisers"},
        {"name": "Dahi Batata Puri", "price": 260, "category": "Appetisers"},
        {"name": "Dahi Vada", "price": 215, "category": "Appetisers"},
        {"name": "Vagharela Idli", "price": 260, "category": "Appetisers"},
        {"name": "Malgapodi Idli", "price": 260, "category": "Appetisers"},
        {"name": "Masala Idli", "price": 260, "category": "Appetisers"},

        # COLD BEVERAGES & MOCKTAILS (Page 3)
        {"name": "Juice (Pineapple)", "price": 210, "category": "Cold Beverages & Mocktails"},
        {"name": "Juice (Watermelon)", "price": 210, "category": "Cold Beverages & Mocktails"},
        {"name": "Juice (Sweet Lime)", "price": 210, "category": "Cold Beverages & Mocktails"},
        {"name": "Fresh Lime (Regular)", "price": 120, "category": "Cold Beverages & Mocktails"},
        {"name": "Fresh Lime (Soda)", "price": 135, "category": "Cold Beverages & Mocktails"},
        {"name": "Jal Jeera (Regular)", "price": 115, "category": "Cold Beverages & Mocktails"},
        {"name": "Jal Jeera (Soda)", "price": 130, "category": "Cold Beverages & Mocktails"},
        {"name": "Ginger Lemon (Regular)", "price": 130, "category": "Cold Beverages & Mocktails"},
        {"name": "Ginger Lemon (Soda)", "price": 150, "category": "Cold Beverages & Mocktails"},
        {"name": "Soda", "price": 80, "category": "Cold Beverages & Mocktails"},
        {"name": "Glass of Aerated Drink", "price": 115, "category": "Cold Beverages & Mocktails"},
        {"name": "Glass of Diet Aerated Drink", "price": 125, "category": "Cold Beverages & Mocktails"},
        {"name": "Bottled Drinking Water", "price": 80, "category": "Cold Beverages & Mocktails"},
        {"name": "Lassi (Sweet)", "price": 190, "category": "Cold Beverages & Mocktails"},
        {"name": "Lassi (Salted)", "price": 190, "category": "Cold Beverages & Mocktails"},
        {"name": "Mango Lassi (In Season)", "price": 215, "category": "Cold Beverages & Mocktails"},
        {"name": "Buttermilk (Chass)", "price": 125, "category": "Cold Beverages & Mocktails"},
        {"name": "Cold Coffee", "price": 170, "category": "Cold Beverages & Mocktails"},
        {"name": "Milk Shake (Vanilla)", "price": 220, "category": "Cold Beverages & Mocktails"},
        {"name": "Milk Shake (Strawberry)", "price": 220, "category": "Cold Beverages & Mocktails"},
        {"name": "Milk Shake (Chocolate)", "price": 220, "category": "Cold Beverages & Mocktails"},
        {"name": "Milk Shake (Chickoo)", "price": 220, "category": "Cold Beverages & Mocktails"},
        {"name": "Mango Milk Shake (In Season)", "price": 250, "category": "Cold Beverages & Mocktails"},
        {"name": "Fruit Punch", "price": 195, "category": "Cold Beverages & Mocktails"},
        {"name": "Pina Colada", "price": 195, "category": "Cold Beverages & Mocktails"},
        {"name": "Orange Blossom", "price": 195, "category": "Cold Beverages & Mocktails"},
        {"name": "Caipiroska (Watermelon)", "price": 220, "category": "Cold Beverages & Mocktails"},
        {"name": "Caipiroska (Kiwi)", "price": 220, "category": "Cold Beverages & Mocktails"},
        {"name": "Caipiroska (Seasonal Mango)", "price": 220, "category": "Cold Beverages & Mocktails"},
        {"name": "Caipiroska (Strawberry)", "price": 220, "category": "Cold Beverages & Mocktails"},
        {"name": "Mock PIMMS", "price": 220, "category": "Cold Beverages & Mocktails"},
        {"name": "Peach Sunrise", "price": 220, "category": "Cold Beverages & Mocktails"},
        {"name": "Iced Tea (Peach)", "price": 160, "category": "Cold Beverages & Mocktails"},
        {"name": "Iced Tea (Lemon)", "price": 160, "category": "Cold Beverages & Mocktails"},
        {"name": "Special Kesar Thandai", "price": 195, "category": "Cold Beverages & Mocktails"},
        {"name": "Fruit Zing Beer", "price": 220, "category": "Cold Beverages & Mocktails"},

        # SOUP (Page 3)
        {"name": "Cream of Vegetable Soup", "price": 185, "category": "Soup"},
        {"name": "Sweet Corn Soup (Plain)", "price": 185, "category": "Soup"},
        {"name": "Sweet Corn Soup (Vegetable)", "price": 185, "category": "Soup"},
        {"name": "Veg Manchow Soup (Non Jain)", "price": 185, "category": "Soup"},
        {"name": "Palak Soup (Non Jain)", "price": 185, "category": "Soup"},
        {"name": "Tomato Soup", "price": 185, "category": "Soup"},
        {"name": "Minestrone Soup", "price": 185, "category": "Soup"},
        {"name": "Rasam", "price": 160, "category": "Soup"},
        {"name": "Dinner Roll", "price": 40, "category": "Soup"},
        {"name": "Stick", "price": 25, "category": "Soup"},
        {"name": "Butter Chiplet", "price": 60, "category": "Soup"},

        # SALAD / RAITA (Page 3)
        {"name": "Green Salad", "price": 120, "category": "Salad / Raita"},
        {"name": "Russian Salad", "price": 215, "category": "Salad / Raita"},
        {"name": "Waldorf Salad", "price": 235, "category": "Salad / Raita"},
        {"name": "Raita - Boondi", "price": 180, "category": "Salad / Raita"},
        {"name": "Raita - Pineapple", "price": 180, "category": "Salad / Raita"},
        {"name": "Raita - Vegetable", "price": 180, "category": "Salad / Raita"},
        {"name": "Raita - Potato", "price": 180, "category": "Salad / Raita"},
        {"name": "Dahi Vada", "price": 215, "category": "Salad / Raita"},
        {"name": "Plain Curd", "price": 160, "category": "Salad / Raita"},
        {"name": "Dahi Idli", "price": 215, "category": "Salad / Raita"},

        # VEGETABLES (Page 4, 5, 6)
        {"name": "Kaju Malai Mutter", "price": 375, "category": "Vegetables"},
        {"name": "Kaju Mawa Korma", "price": 375, "category": "Vegetables"},
        {"name": "Paneer Mutter", "price": 375, "category": "Vegetables"},
        {"name": "Paneer Chole", "price": 375, "category": "Vegetables"},
        {"name": "Paneer Lazeez", "price": 395, "category": "Vegetables"},
        {"name": "Paneer Butter Masala", "price": 395, "category": "Vegetables"},
        {"name": "Paneer Tikka Masala", "price": 395, "category": "Vegetables"},
        {"name": "Paneer Bhurji in Butter", "price": 375, "category": "Vegetables"},
        {"name": "Paneer Methi Malai", "price": 390, "category": "Vegetables"},
        {"name": "Paneer Mushroom Masala", "price": 390, "category": "Vegetables"},
        {"name": "Paneer Palak", "price": 390, "category": "Vegetables"},
        {"name": "Kadai Paneer", "price": 390, "category": "Vegetables"},
        {"name": "Shahi Paneer Korma", "price": 390, "category": "Vegetables"},
        {"name": "Paneer Kofta", "price": 390, "category": "Vegetables"},
        {"name": "Corn Bhurji in Butter", "price": 375, "category": "Vegetables"},
        {"name": "Baby Corn with Vegetable", "price": 375, "category": "Vegetables"},
        {"name": "Corn Peas Green Masala", "price": 375, "category": "Vegetables"},
        {"name": "Corn Capsicum Red Masala", "price": 375, "category": "Vegetables"},
        {"name": "Vegetable Bhurji in Butter", "price": 325, "category": "Vegetables"},
        {"name": "Vegetable Makhanwala", "price": 375, "category": "Vegetables"},
        {"name": "Navratan Korma", "price": 375, "category": "Vegetables"},
        {"name": "Vegetable Kolhapuri", "price": 375, "category": "Vegetables"},
        {"name": "Kadai Vegetable", "price": 375, "category": "Vegetables"},
        {"name": "Kadai Aloo", "price": 375, "category": "Vegetables"},
        {"name": "Kadai Mushroom", "price": 375, "category": "Vegetables"},
        {"name": "Vegetable Jaipuri", "price": 375, "category": "Vegetables"},
        {"name": "Vegetable Jalfrazie", "price": 375, "category": "Vegetables"},
        {"name": "Green Kabab Masala", "price": 375, "category": "Vegetables"},
        {"name": "Mix Vegetable Green Masala", "price": 375, "category": "Vegetables"},
        {"name": "Palak (Regular)", "price": 325, "category": "Vegetables"},
        {"name": "Palak (Lasooni)", "price": 325, "category": "Vegetables"},
        {"name": "Palak (Chana)", "price": 325, "category": "Vegetables"},
        {"name": "Vegetable Chilli Milli", "price": 375, "category": "Vegetables"},
        {"name": "Paneer Lababdar", "price": 390, "category": "Vegetables"},
        {"name": "Chana Masala", "price": 325, "category": "Vegetables"},
        {"name": "Baigan Bharta", "price": 325, "category": "Vegetables"},
        {"name": "Bhindi Masala", "price": 325, "category": "Vegetables"},
        {"name": "Italian Korma", "price": 375, "category": "Vegetables"},
        {"name": "Malai Kofta", "price": 375, "category": "Vegetables"},
        {"name": "Dum Aloo Punjabi", "price": 375, "category": "Vegetables"},
        {"name": "Aloo Gobhi", "price": 325, "category": "Vegetables"},
        {"name": "Jeera Aloo", "price": 325, "category": "Vegetables"},
        {"name": "Dal Palak", "price": 300, "category": "Vegetables"},
        {"name": "Dal Fried in Butter", "price": 300, "category": "Vegetables"},
        {"name": "Dal Makhani (Black)", "price": 330, "category": "Vegetables"},
        {"name": "Dal Surti", "price": 200, "category": "Vegetables"},
        {"name": "Dal Lachka", "price": 200, "category": "Vegetables"},
        {"name": "Dahi Kadhi", "price": 200, "category": "Vegetables"},
        {"name": "Sambar", "price": 200, "category": "Vegetables"},
        {"name": "Gujarati Vegetable", "price": 250, "category": "Vegetables"},
        {"name": "Undhio (in season)", "price": 275, "category": "Vegetables"},

        # MEALS (Page 7)
        {"name": "Chana Bhatura", "price": 295, "category": "Meals"},
        {"name": "Puri Bhaji", "price": 235, "category": "Meals"},
        {"name": "Shrikhand Puri", "price": 260, "category": "Meals"},
        {"name": "Basundi Puri", "price": 260, "category": "Meals"},
        {"name": "Aamras Puri (in season)", "price": 300, "category": "Meals"},
        {"name": "Rice with Sambar & Papad", "price": 245, "category": "Meals"},
        {"name": "Rice with Kadhi & Papad", "price": 245, "category": "Meals"},
        {"name": "Pulao with Dahi Kadhi & Papad", "price": 280, "category": "Meals"},
        {"name": "Khichdi with Kadhi & Papad", "price": 270, "category": "Meals"},
        {"name": "Masala Khichdi with Kadhi & Papad", "price": 290, "category": "Meals"},
        {"name": "Rice with Lachha Dal / Surti Dal / Rasam & Papad", "price": 245, "category": "Meals"},

        # ROTI (Page 7)
        {"name": "Tandoori Roti (Plain)", "price": 70, "category": "Roti"},
        {"name": "Tandoori Roti (Butter)", "price": 80, "category": "Roti"},
        {"name": "Kulcha (Plain)", "price": 85, "category": "Roti"},
        {"name": "Kulcha (Butter)", "price": 105, "category": "Roti"},
        {"name": "Naan (Plain)", "price": 85, "category": "Roti"},
        {"name": "Naan (Butter)", "price": 105, "category": "Roti"},
        {"name": "Masala Kulcha", "price": 105, "category": "Roti"},
        {"name": "Onion Kulcha", "price": 105, "category": "Roti"},
        {"name": "Garlic Naan", "price": 135, "category": "Roti"},
        {"name": "Chilly Garlic Naan", "price": 135, "category": "Roti"},
        {"name": "Chilly Cheese Naan", "price": 135, "category": "Roti"},
        {"name": "Tawa Paratha (Plain)", "price": 100, "category": "Roti"},
        {"name": "Tawa Paratha (Butter)", "price": 110, "category": "Roti"},
        {"name": "Tawa Paratha (Pudina)", "price": 110, "category": "Roti"},
        {"name": "Tawa Paratha (Methi)", "price": 110, "category": "Roti"},
        {"name": "Aloo Paratha", "price": 125, "category": "Roti"},
        {"name": "Butter Tandoori Lachha Paratha", "price": 125, "category": "Roti"},
        {"name": "Reshmi Paratha", "price": 105, "category": "Roti"},
        {"name": "Roomali Roti (Plain)", "price": 90, "category": "Roti"},
        {"name": "Roomali Roti (Butter)", "price": 105, "category": "Roti"},
        {"name": "Puri (Six)", "price": 85, "category": "Roti"},
        {"name": "Bhatura", "price": 90, "category": "Roti"},
        {"name": "Tawa Chapati (Phulka)", "price": 45, "category": "Roti"},
        {"name": "Papad (Roasted)", "price": 50, "category": "Roti"},
        {"name": "Masala Papad (Fried)", "price": 70, "category": "Roti"},
        {"name": "Masala Khichia Papad (Fried)", "price": 115, "category": "Roti"},
        {"name": "Papad Chura", "price": 115, "category": "Roti"},
        {"name": "Thepla", "price": 50, "category": "Roti"},

        # RICE (Page 8)
        {"name": "Plain Rice", "price": 195, "category": "Rice"},
        {"name": "Palak Garlic Rice", "price": 270, "category": "Rice"},
        {"name": "Curd Rice & Papad (Dahi Bhaat)", "price": 245, "category": "Rice"},
        {"name": "Vegetable Pulao", "price": 240, "category": "Rice"},
        {"name": "Peas Pulao", "price": 240, "category": "Rice"},
        {"name": "Jeera Rice", "price": 240, "category": "Rice"},
        {"name": "Vegetable Biryani", "price": 280, "category": "Rice"},
        {"name": "Handi Biryani", "price": 290, "category": "Rice"},
        {"name": "Khichdi with Papad", "price": 240, "category": "Rice"},
        {"name": "Masala Khichdi with Papad", "price": 270, "category": "Rice"},
        {"name": "Dal Khichdi with Papad", "price": 270, "category": "Rice"},

        # GUJARATI THALI (Page 8)
        {"name": "Gujarati Thali Dinner", "price": 450, "category": "Gujarati Thali"},

        # FROM THE SOUTH (Page 9)
        {"name": "Idli", "price": 140, "category": "From The South"},
        {"name": "Dahi Idli", "price": 215, "category": "From The South"},
        {"name": "Idli Chips", "price": 190, "category": "From The South"},
        {"name": "Rava Idli", "price": 170, "category": "From The South"},
        {"name": "Rasam Idli", "price": 185, "category": "From The South"},
        {"name": "Rasam Vada", "price": 185, "category": "From The South"},
        {"name": "Vagharela Idli", "price": 260, "category": "From The South"},
        {"name": "Malgapodi Idli (South)", "price": 260, "category": "From The South"},
        {"name": "Masala Idli (South)", "price": 260, "category": "From The South"},
        {"name": "Medu Vada", "price": 150, "category": "From The South"},
        {"name": "Idli Vada (South)", "price": 150, "category": "From The South"},
        {"name": "Upma", "price": 140, "category": "From The South"},
        {"name": "Ghee Dosa (Sada)", "price": 175, "category": "From The South"},
        {"name": "Ghee Dosa (Masala)", "price": 195, "category": "From The South"},
        {"name": "Mysore Dosa (Sada)", "price": 180, "category": "From The South"},
        {"name": "Mysore Dosa (Masala)", "price": 200, "category": "From The South"},
        {"name": "Rava Dosa (Sada)", "price": 185, "category": "From The South"},
        {"name": "Rava Dosa (Masala)", "price": 205, "category": "From The South"},
        {"name": "Onion Rava Dosa (Sada)", "price": 185, "category": "From The South"},
        {"name": "Onion Rava Dosa (Masala)", "price": 205, "category": "From The South"},
        {"name": "Uttapam", "price": 175, "category": "From The South"},
        {"name": "Onion Uttapam", "price": 185, "category": "From The South"},
        {"name": "Mix Uttapam (Onion, Tomato & Chilli) (Regular)", "price": 195, "category": "From The South"},
        {"name": "Mix Uttapam (Onion, Tomato & Chilli) (Cheese)", "price": 240, "category": "From The South"},
        {"name": "Vegetable Uttapam", "price": 210, "category": "From The South"},
        {"name": "Cheese Uttapam (Regular)", "price": 225, "category": "From The South"},
        {"name": "Cheese Uttapam (Vegetable)", "price": 240, "category": "From The South"},
        {"name": "Cheese Dosa (Sada)", "price": 215, "category": "From The South"},
        {"name": "Cheese Dosa (Masala)", "price": 240, "category": "From The South"},
        {"name": "Cheese Mysore Dosa (Sada)", "price": 200, "category": "From The South"},
        {"name": "Cheese Mysore Dosa (Masala)", "price": 225, "category": "From The South"},

        # SANDWICHES (Page 10)
        {"name": "Bread Butter", "price": 135, "category": "Sandwiches"},
        {"name": "Toast Butter", "price": 145, "category": "Sandwiches"},
        {"name": "Vegetable Sandwich (Regular)", "price": 155, "category": "Sandwiches"},
        {"name": "Vegetable Sandwich (Cheese)", "price": 200, "category": "Sandwiches"},
        {"name": "Chutney Sandwich", "price": 140, "category": "Sandwiches"},
        {"name": "Vegetable Grilled Sandwich (Regular)", "price": 190, "category": "Sandwiches"},
        {"name": "Vegetable Grilled Sandwich (Cheese)", "price": 215, "category": "Sandwiches"},
        {"name": "Vegetable Club Sandwich (Grilled)", "price": 260, "category": "Sandwiches"},
        {"name": "Cheese Sandwich (Regular)", "price": 180, "category": "Sandwiches"},
        {"name": "Cheese Sandwich (Toast)", "price": 195, "category": "Sandwiches"},
        {"name": "Cheese Sandwich (Grilled)", "price": 205, "category": "Sandwiches"},
        {"name": "Tomato Cheese Sandwich", "price": 185, "category": "Sandwiches"},
        {"name": "Tomato Omelette Sandwich (Regular)", "price": 180, "category": "Sandwiches"},
        {"name": "Tomato Omelette Sandwich (Toast)", "price": 200, "category": "Sandwiches"},
        {"name": "Tomato Omelette Sandwich (Grilled)", "price": 220, "category": "Sandwiches"},
        {"name": "Tomato Omelette Cheese Sandwich (Regular)", "price": 200, "category": "Sandwiches"},
        {"name": "Tomato Omelette Cheese Sandwich (Toast)", "price": 220, "category": "Sandwiches"},
        {"name": "Tomato Omelette Cheese Sandwich (Grilled)", "price": 240, "category": "Sandwiches"},
        {"name": "Russain Salad Sandwich", "price": 210, "category": "Sandwiches"},

        # HOT BEVERAGES (Page 10)
        {"name": "Tea", "price": 105, "category": "Hot Beverages"},
        {"name": "Masala Tea", "price": 115, "category": "Hot Beverages"},
        {"name": "Coffee", "price": 110, "category": "Hot Beverages"},
        {"name": "Nes Coffee", "price": 115, "category": "Hot Beverages"},
        {"name": "Hot Chocolate", "price": 125, "category": "Hot Beverages"},

        # SWEETS (Page 11)
        {"name": "Gulab Jamun", "price": 160, "category": "Sweets"},
        {"name": "Kesari Shrikhand", "price": 190, "category": "Sweets"},
        {"name": "Basundi", "price": 190, "category": "Sweets"},
        {"name": "Aamras (in season)", "price": 250, "category": "Sweets"},

        # DESSERTS (Page 11)
        {"name": "Fruit Salad (Plain)", "price": 155, "category": "Desserts"},
        {"name": "Fruit Salad (with Ice Cream)", "price": 200, "category": "Desserts"},
        {"name": "Vanilla Ice Cream", "price": 175, "category": "Desserts"},
        {"name": "Vanilla with Chocolate Sauce & Nuts", "price": 210, "category": "Desserts"},
        {"name": "Ice Cream (Chocolate Brownie)", "price": 185, "category": "Desserts"},
        {"name": "Ice Cream (Strawberry)", "price": 185, "category": "Desserts"},
        {"name": "Ice Cream (Mango)", "price": 185, "category": "Desserts"},
        {"name": "Ice Cream (Kesar Pista)", "price": 185, "category": "Desserts"},
        {"name": "Ice Cream (Butter Scotch)", "price": 185, "category": "Desserts"},
        {"name": "Rose Petal Ice Cream", "price": 210, "category": "Desserts"},
        {"name": "Malai Kulfi", "price": 180, "category": "Desserts"},
    ]

    # Find the item in the menu
    matched_item = None
    for item in MENU_DATA:
        # Simple fuzzy matching: case-insensitive exact match for now
        if item["name"].lower() == item_name.lower():
            matched_item = item
            break
    
    # If no exact match, try a more lenient fuzzy match (e.g., contains)
    if not matched_item:
        for item in MENU_DATA:
            if item_name.lower() in item["name"].lower():
                matched_item = item
                break

    if not matched_item:
        return {"status": "FAILED", "message": f"Item '{item_name}' not found on the menu. Please check the spelling or browse the menu for available items."}

    current_order = context.state.get("current_order", [])
    
    # Check if item already exists in order
    found_in_order = False
    for order_item in current_order:
        if order_item["name"].lower() == matched_item["name"].lower():
            order_item["quantity"] += quantity
            found_in_order = True
            break
    
    if not found_in_order:
        current_order.append({"name": matched_item["name"], "price": matched_item["price"], "quantity": quantity})
    
    context.state["current_order"] = current_order
    
    total_items_in_order = sum(item["quantity"] for item in current_order)
    return {"status": "SUCCESS", "message": f"Added {quantity} {matched_item['name']} to your order.", "current_order_count": total_items_in_order}