def get_service_center_by_city(city: str) -> str:
    """
    This function returns service center addresses for a given city.
    Args:
        city (str): name of the city.
    Returns:
        Service center address in the given city.
    """

    city_lower = city.lower()

    if "mumbai" in city_lower:
        return {
            "addresses": [
                {
                    "name": "Mumbai Central Service Center",
                    "address": "12 MG Road, Mumbai, Maharashtra 400001"
                }
            ],
            "status": "SUCCESS"
        }

    elif "delhi" in city_lower:
        return {
            "addresses": [
                {
                    "name": "Delhi Service Hub",
                    "address": "45 Connaught Place, New Delhi, Delhi 110001"
                }
            ],
            "status": "SUCCESS"
        }

    elif "bangalore" in city_lower or "bengaluru" in city_lower:
        return {
            "addresses": [
                {
                    "name": "Bangalore Service Center",
                    "address": "78 Brigade Road, Bengaluru, Karnataka 560001"
                }
            ],
            "status": "SUCCESS"
        }

    elif "hyderabad" in city_lower:
        return {
            "addresses": [
                {
                    "name": "Hyderabad Service Point",
                    "address": "22 Banjara Hills, Hyderabad, Telangana 500034"
                }
            ],
            "status": "SUCCESS"
        }

    else:
        return {
            "status": "NOT_FOUND"
        }
